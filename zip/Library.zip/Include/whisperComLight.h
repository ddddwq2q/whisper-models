#pragma once
#include "iMediaFoundation.cl.h"
#include "iContext.cl.h"
#include "iTranscribeResult.cl.h"