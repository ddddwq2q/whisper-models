#pragma once
#include "iMediaFoundation.h"
#include "iContext.h"
#include "iTranscribeResult.h"